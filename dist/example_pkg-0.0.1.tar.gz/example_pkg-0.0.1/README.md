# python-packaging-example


Reference

https://packaging.python.org/tutorials/packaging-projects/