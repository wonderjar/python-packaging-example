# python-packaging-example


Reference

https://packaging.python.org/tutorials/packaging-projects/https://packaging.python.org/tutorials/packaging-projects/


```
pip install setuptools wheel

python setup.py sdist bdist_wheel

```
